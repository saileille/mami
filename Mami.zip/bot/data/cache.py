"""Cached data."""

CURRENCY_DATA = {}
