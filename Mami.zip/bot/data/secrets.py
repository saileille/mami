"""Secret data for the bot owner's eyes only."""

# Used to connect the bot to Discord account.
BOT_TOKEN = "MzQ4OTMzOTY1NjQzNzc2MDAw.DXQ71w.tc2-D_buAwWFAHUNwbNOAi9fiLc"

# Used for the currency command. You can get yours from https://fixer.io/
CURRENCY_API_KEY = "4dff4aa9f502f522b61a031156b6c998"
